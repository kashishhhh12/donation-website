
const express = require("express");
const router = express.Router();

const leaderboardData = [
  { name: "Ritika", amount: 4500 },
  { name: "Aditya", amount: 3200 },
  { name: "Kunal", amount: 2800 },
  { name: "Neha", amount: 1800 },
  { name: "Sahil", amount: 1200 }
];

router.get("/", (req, res) => {
  const { filter } = req.query;
  let data = leaderboardData;

  if (filter === "daily") {
    data = leaderboardData.slice(0, 2);
  } else if (filter === "weekly") {
    data = leaderboardData.slice(0, 4);
  }

  res.json(data);
});

module.exports = router;
