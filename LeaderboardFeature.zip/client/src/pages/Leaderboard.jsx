
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Leaderboard = () => {
  const [data, setData] = useState([]);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    axios.get(`http://localhost:5000/api/leaderboard?filter=${filter}`)
      .then(res => setData(res.data))
      .catch(err => console.error(err));
  }, [filter]);

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Leaderboard</h1>

      <div className="mb-4">
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="border px-3 py-1 rounded"
        >
          <option value="all">All-Time</option>
          <option value="weekly">Weekly</option>
          <option value="daily">Daily</option>
        </select>
      </div>

      <table className="w-full bg-white shadow rounded overflow-hidden">
        <thead className="bg-gray-100">
          <tr>
            <th className="text-left p-2">Rank</th>
            <th className="text-left p-2">Name</th>
            <th className="text-left p-2">Total Raised</th>
          </tr>
        </thead>
        <tbody>
          {data.map((intern, index) => (
            <tr
              key={index}
              className={index === 0 ? "bg-yellow-100 font-semibold" : ""}
            >
              <td className="p-2">{index + 1}</td>
              <td className="p-2">{intern.name}</td>
              <td className="p-2">₹{intern.amount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Leaderboard;
