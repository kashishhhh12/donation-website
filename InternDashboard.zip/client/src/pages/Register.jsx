import React, { useState } from 'react';
import axios from 'axios';
import AuthForm from '../components/AuthForm';

const Register = () => {
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/auth/register", formData);
      alert("Registered successfully! Token: " + res.data.token);
    } catch (err) {
      alert(err.response.data.msg);
    }
  };

  return <AuthForm formData={formData} setFormData={setFormData} handleSubmit={handleSubmit} buttonText="Register" />;
};

export default Register;