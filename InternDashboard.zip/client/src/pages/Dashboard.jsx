import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Dashboard = () => {
  const [data, setData] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    axios.get("http://localhost:5000/api/dashboard", {
      headers: { Authorization: token }
    }).then(res => setData(res.data))
      .catch(err => alert("Unauthorized"));
  }, []);

  if (!data) return <div className="text-center mt-20">Loading...</div>;

  const { name, referralCode, totalRaised, donors, transactions } = data;
  const milestones = [500, 1000, 2000];
  const progress = Math.min((totalRaised / 2000) * 100, 100);

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Welcome, {name}</h1>

      <div className="bg-gray-100 p-4 rounded shadow">
        <p><strong>Referral Code:</strong> {referralCode}</p>
        <button onClick={() => navigator.clipboard.writeText(referralCode)} className="text-blue-600 text-sm">Copy</button>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white shadow p-4 rounded">
          <p className="text-gray-600">Total Raised</p>
          <h2 className="text-xl font-bold">₹{totalRaised}</h2>
        </div>
        <div className="bg-white shadow p-4 rounded">
          <p className="text-gray-600">Donors</p>
          <h2 className="text-xl font-bold">{donors}</h2>
        </div>
      </div>

      <div>
        <p className="mb-1">Milestone Progress</p>
        <div className="w-full bg-gray-300 rounded-full h-4">
          <div className="bg-green-500 h-4 rounded-full" style={{ width: `${progress}%` }}></div>
        </div>
        <div className="flex justify-between text-sm text-gray-500 mt-1">
          {milestones.map(m => (
            <span key={m}>₹{m}</span>
          ))}
        </div>
      </div>

      <div>
        <h3 className="font-semibold mb-2">Recent Donations</h3>
        <table className="w-full text-left bg-white rounded shadow">
          <thead>
            <tr>
              <th className="p-2 border-b">Name</th>
              <th className="p-2 border-b">Amount</th>
              <th className="p-2 border-b">Date</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((tx, i) => (
              <tr key={i}>
                <td className="p-2 border-b">{tx.name}</td>
                <td className="p-2 border-b">₹{tx.amount}</td>
                <td className="p-2 border-b">{tx.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Dashboard;