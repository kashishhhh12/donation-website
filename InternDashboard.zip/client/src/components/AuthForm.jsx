import React from 'react';

const AuthForm = ({ formData, setFormData, handleSubmit, buttonText }) => (
  <form
    onSubmit={handleSubmit}
    className="bg-white p-8 rounded-lg shadow-md w-full max-w-md mx-auto mt-10 space-y-6"
  >
    {buttonText === "Register" && (
      <input
        type="text"
        name="name"
        placeholder="Name"
        className="w-full px-4 py-2 border rounded"
        value={formData.name}
        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
        required
      />
    )}
    <input
      type="email"
      name="email"
      placeholder="Email"
      className="w-full px-4 py-2 border rounded"
      value={formData.email}
      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
      required
    />
    <input
      type="password"
      name="password"
      placeholder="Password"
      className="w-full px-4 py-2 border rounded"
      value={formData.password}
      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
      required
    />
    <button
      type="submit"
      className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600"
    >
      {buttonText}
    </button>
  </form>
);

export default AuthForm;