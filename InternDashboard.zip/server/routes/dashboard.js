const express = require("express");
const Intern = require("../models/Intern");
const jwt = require("jsonwebtoken");

const router = express.Router();

const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization;
  if (!token) return res.status(401).json({ msg: "No token" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded.id;
    next();
  } catch (err) {
    res.status(401).json({ msg: "Invalid token" });
  }
};

router.get("/", authMiddleware, async (req, res) => {
  try {
    const intern = await Intern.findById(req.user);
    if (!intern) return res.status(404).json({ msg: "Intern not found" });

    const fakeTransactions = [
      { name: "Ravi", amount: 200, date: "2024-06-01" },
      { name: "Asha", amount: 300, date: "2024-06-10" },
      { name: "Neha", amount: 500, date: "2024-06-12" },
    ];

    res.json({
      name: intern.name,
      referralCode: intern.referralCode,
      totalRaised: intern.totalRaised || 1000,
      donors: intern.donors || 3,
      transactions: fakeTransactions,
    });
  } catch (err) {
    res.status(500).json({ msg: "Error" });
  }
});

module.exports = router;