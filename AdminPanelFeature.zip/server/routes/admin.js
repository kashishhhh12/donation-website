
const express = require("express");
const router = express.Router();

let donations = [
  { id: 1, intern: "Ritika", amount: 450, status: "approved" },
  { id: 2, intern: "Aditya", amount: 700, status: "pending" },
  { id: 3, intern: "Kunal", amount: 320, status: "approved" }
];

router.get("/donations", (req, res) => {
  const { search } = req.query;
  if (search) {
    const filtered = donations.filter(d => d.intern.toLowerCase().includes(search.toLowerCase()));
    res.json(filtered);
  } else {
    res.json(donations);
  }
});

router.post("/donations/:id/approve", (req, res) => {
  const donation = donations.find(d => d.id === parseInt(req.params.id));
  if (donation) {
    donation.status = "approved";
    res.json({ message: "Donation approved" });
  } else {
    res.status(404).json({ message: "Not found" });
  }
});

router.delete("/donations/:id", (req, res) => {
  donations = donations.filter(d => d.id !== parseInt(req.params.id));
  res.json({ message: "Donation removed" });
});

module.exports = router;
