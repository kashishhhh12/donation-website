
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminPanel = () => {
  const [donations, setDonations] = useState([]);
  const [search, setSearch] = useState("");

  const fetchDonations = () => {
    axios.get(`http://localhost:5000/api/admin/donations?search=${search}`)
      .then(res => setDonations(res.data));
  };

  useEffect(() => {
    fetchDonations();
  }, [search]);

  const approveDonation = (id) => {
    axios.post(`http://localhost:5000/api/admin/donations/${id}/approve`)
      .then(() => fetchDonations());
  };

  const removeDonation = (id) => {
    axios.delete(`http://localhost:5000/api/admin/donations/${id}`)
      .then(() => fetchDonations());
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Admin Panel</h1>
      <input
        type="text"
        placeholder="Search by intern"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="mb-4 p-2 border rounded w-full"
      />
      <table className="w-full bg-white shadow rounded">
        <thead className="bg-gray-100">
          <tr>
            <th className="p-2 text-left">Intern</th>
            <th className="p-2 text-left">Amount</th>
            <th className="p-2 text-left">Status</th>
            <th className="p-2 text-left">Actions</th>
          </tr>
        </thead>
        <tbody>
          {donations.map(d => (
            <tr key={d.id}>
              <td className="p-2">{d.intern}</td>
              <td className="p-2">₹{d.amount}</td>
              <td className="p-2 capitalize">{d.status}</td>
              <td className="p-2 space-x-2">
                {d.status !== "approved" && (
                  <button
                    className="px-3 py-1 bg-green-500 text-white rounded"
                    onClick={() => approveDonation(d.id)}
                  >
                    Approve
                  </button>
                )}
                <button
                  className="px-3 py-1 bg-red-500 text-white rounded"
                  onClick={() => removeDonation(d.id)}
                >
                  Remove
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminPanel;
