const App = () => (
  <div className="flex flex-col items-center mt-10">
    <h1 className="text-2xl font-bold mb-4">Welcome to Donation Platform</h1>
    <a href="/register" className="text-blue-500 underline mb-2">Register</a>
    <a href="/login" className="text-blue-500 underline">Login</a>
  </div>
);

export default App;