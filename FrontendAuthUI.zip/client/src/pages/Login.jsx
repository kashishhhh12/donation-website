import React, { useState } from 'react';
import axios from 'axios';
import AuthForm from '../components/AuthForm';

const Login = () => {
  const [formData, setFormData] = useState({ email: '', password: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:5000/api/auth/login", formData);
      alert("Logged in! Token: " + res.data.token);
    } catch (err) {
      alert(err.response.data.msg);
    }
  };

  return <AuthForm formData={formData} setFormData={setFormData} handleSubmit={handleSubmit} buttonText="Login" />;
};

export default Login;